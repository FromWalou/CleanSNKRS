import React from 'react';

const AdminPanel = () => {
	return ();
};

export default AdminPanel;