import React from 'react';

const Cleaner = () => {
	return ();
};

export default Cleaner;